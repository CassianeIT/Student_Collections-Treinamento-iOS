//
//  StructMyLibrary.swift
//  My Library
//
//  Created by Curitiba on 22/03/21.
//

import Foundation
import UIKit

struct Book {
    var image: String
    var title: String
    var authors: String
}
