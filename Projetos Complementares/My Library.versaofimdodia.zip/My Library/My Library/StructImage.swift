//
//  StructImage.swift
//  My Library
//
//  Created by Curitiba on 22/03/21.
//

import Foundation
import UIKit

struct Image {
    var name: String
}
