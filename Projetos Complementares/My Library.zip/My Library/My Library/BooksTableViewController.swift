//
//  BooksTableViewController.swift
//  My Library
//
//  Created by Curitiba on 22/03/21.
//

import UIKit

class BooksTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    // MARK: - Array Books
    
    var image: [String] = ["A Guide to Tea", "Blasting for Health", "Bosch", "Date to Lead", "Doodle All Year", "Drawing People", "Drinking Saints", "Ein Neues Land", "Goya", "How to Draw Cats", "Pressed Fairy Book", "What to Say"]
    
    var books: [String] = ["A Guide to Tea", "Blasting Optimum for Health Recipe Book", "Bosch", "Date to Lead", "Doodle All Year", "Drawing People", "Drinking  with the Saints", "Ein Neues Land", "The Life and Complete Work Francisco Goya", "How to Draw Cats", "Lady Cottington's Pressed Fairy Book", "What to Say When You Talk to Yourself"]
    
    var authors: [String] = ["Adagio Teas", "NutriBullet", "Laurinda Dixon", "Brené Brown", "Taro Gomi", "Barbara Bradley", "Michael P. Foley", "Shaun Tan", "P. Gassier & J Wilson", "Janet Rancan", "Lady Cottington", "Shad Helmstetter"]
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return books.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BooksCell", for: indexPath)
                
        
        cell.textLabel?.text = books[indexPath.row]
        cell.detailTextLabel?.text = authors[indexPath.row]
        

        return cell
    }
  
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let viewController = storyboard?.instantiateViewController(withIdentifier: "Cover") as? ImageViewController {
            viewController.selectImage = image[indexPath.row]
            navigationController?.pushViewController(viewController, animated: true)
            
        }
    }


  

}
