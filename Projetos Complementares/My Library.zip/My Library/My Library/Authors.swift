//
//  Authors.swift
//  My Library
//
//  Created by Curitiba on 22/03/21.
//

import Foundation

struct Authors {
    var authors: String
}
