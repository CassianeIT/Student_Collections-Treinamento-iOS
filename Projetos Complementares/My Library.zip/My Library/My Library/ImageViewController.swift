//
//  ImageViewController.swift
//  My Library
//
//  Created by Curitiba on 22/03/21.
//

import Foundation
import UIKit


import UIKit

class ImageViewController: UIViewController {
     
    override func viewDidLoad() {
       super.viewDidLoad()
    
        borda()
        
        if let imageToLoad = selectImage {
            coverOutlet.image = UIImage(named: imageToLoad)

        }
   }
    var selectImage: String? 
    
    
    
    @IBOutlet weak var coverOutlet: UIImageView!
       
    func borda () {
        coverOutlet.layer.cornerRadius = 15

    }
}

